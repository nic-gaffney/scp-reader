# scp-reader
Read the SCP wiki from the terminal
